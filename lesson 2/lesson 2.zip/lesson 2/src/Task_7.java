import java.util.Arrays;
import java.util.Random;
public class Task_7 {

    public static void shiftN(int[] arr4, int n) {
        Random rnd = new Random();
        for (int i = 0; i < arr4.length; i++) {
            arr4[i] = rnd.nextInt(50);
        }
        System.out.print("Массив до: ");
        System.out.println(Arrays.toString(arr4));

        boolean isTrue = n < 0;
        if(isTrue) {
            n *= -1;
            int count = n;

            while (n > 0) {
                int iter = 0;
                for (int i = n - 1; iter < arr4.length - count; i++) { // 0
                    int t = arr4[i];
                    arr4[i] = arr4[i + 1];
                    arr4[i + 1] = t;
                    iter++;
                }
                --n;
            }
        }else
            n *= -1;
            int count = n;
            while (n < 0) {
                int iter = 0;
                for (int i = arr4.length + n; iter < arr4.length + count; i--) { // 0
                    int t = arr4[i];
                    arr4[i] = arr4[i - 1];
                    arr4[i - 1] = t;
                    iter++;
                }
                ++n;
            }
        System.out.println("Массив после: " + Arrays.toString(arr4));
    }
}
